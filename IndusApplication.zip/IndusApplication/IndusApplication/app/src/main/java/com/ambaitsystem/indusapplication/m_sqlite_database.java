package com.ambaitsystem.indusapplication;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.EditText;

public class m_sqlite_database extends Activity {
	//globle Variable
	EditText txtname;
	
	String Name;
	public SQLiteDatabase db=null;
    @Override
    public void onCreate(Bundle savedInstanceState) {
    
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m_sqlite_database);
        
        txtname = (EditText) findViewById(R.id.edittxtName_db);
        
       
        //Create table 
        				db =(new DbBasic(this)).getWritableDatabase();
			        	db.execSQL("CREATE TABLE IF NOT EXISTS test (_id INTEGER AUTO_INCREMENT,StudentName TEXT);");
			         	db.close();
	   //Insert Value in Table
			         	db =(new DbBasic(this)).getWritableDatabase();
			        	db.execSQL("INSERT INTO test (StudentName) VALUES('Dhaval');");
			         	db.close();
	  //Show Value from Table
			         	db =(new DbBasic(this)).getReadableDatabase();
			         	Cursor CurstudentDetail =  db.rawQuery("Select * from test",null);
			         	startManagingCursor(CurstudentDetail);
			         	CurstudentDetail.moveToFirst();
			         	txtname.setText( CurstudentDetail.getString(1));
						
						if (CurstudentDetail.moveToFirst()){
						do {
							// Passing values 
							String column1 = CurstudentDetail.getString(0);
							String column2 = CurstudentDetail.getString(1);
							String column3 = CurstudentDetail.getString(2); 
							// Do something Here with values
						} while(CurstudentDetail.moveToNext());
}

    }

	
}
