package com.ambaitsystem.indusapplication;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class e_Intent_Destination_Activity extends Activity {
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    
        super.onCreate(savedInstanceState);
        setContentView(R.layout.e_intent_destination_activity);
       
      /*  Bundle extras = getIntent().getExtras();
        if (extras == null) 
        {
        		return;
        }
       
        String Name = extras.getString("Paramenter");
        
       TextView txtName =(TextView)findViewById(R.id.txtintentDestination);
       txtName.setText(Name); */
        
    }

	
}