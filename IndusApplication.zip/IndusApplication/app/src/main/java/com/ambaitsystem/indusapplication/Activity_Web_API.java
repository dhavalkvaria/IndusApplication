package com.ambaitsystem.indusapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Activity_Web_API extends AppCompatActivity {
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webapi);

        btn = findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //If you click on More i.e. length of data_user is Greater than 0
                //So if it is Gt 0
                // Remove data at start_page_count -> This will remove More

                //Call Asynch task to offer a Te

                StringRequest strReq = new StringRequest(Request.Method.POST,
                        "http://192.168.24.129/project/v1/index.php/user/login", new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject obj = new JSONObject(response);

                            // check for error flag
                            if (obj.getBoolean("error") == false) {

                                Toast.makeText(getBaseContext(), "Information Saved.Press NEXT to continue.", Toast.LENGTH_SHORT).show();

                            } else {
                                // error in fetching chat rooms
                                Toast.makeText(getBaseContext(), "Check Internet Connection #1", Toast.LENGTH_SHORT).show();

                            }

                        } catch (JSONException e) {
                            // Log.v("Error","#$"+e.toString());
                            Toast.makeText(getBaseContext(), "Check Internet Connection #2", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        NetworkResponse networkResponse = error.networkResponse;
                        error.printStackTrace();

                        Toast.makeText(getBaseContext(), "Check Internet Connection #3", Toast.LENGTH_SHORT).show();

                    }
                }) {

                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<String, String>();
                        //String id, String name, String email, String dob, String home_Address, String phone_number, String current_place,
                        // String transplace1, String transplace2, String transplace3, String transplace4, String transplace5, String sex,
                        // String marrital_status, String current_dist, String dist_to_transfer, String q1, String q2, String q3

                        params.put("name","Poonam");
                        params.put("email", "Poonam@gmail.com");
                        params.put("validationcode", "123");

                        Log.v("Parameter", "#$" + params);
                        return params;
                    }

                    ;
                };

                //Adding request to request queue
                MyApplication_OnlineTransfer.getInstance().addToRequestQueue(strReq);
            }
        });

    }


}
