package com.ambaitsystem.indusapplication;

/**
 * Created by USER on 11/23/2017.
 */

public class EndPoints
{
    public static final String LATEST_VALUES_NEW = "aHR0cDovL3Rvd25sYWR5LnByYXh3YXJlLmNvbS92MS9pbmRleF92Mi5waHAvc2VhcmNoX3ZhbHVlc19sYXRlc3RfdXBkYXRlc19ORVc=";
}
