package com.ambaitsystem.indusapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class LayoutDemoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.linearlayout);
        //setContentView(R.layout.relativelayout);
        setContentView(R.layout.scrollview);

    }
}
